import pandas as pd
import warnings

df = pd.read_csv(r"C:\Users\amala\Downloads\Islamic Battles.csv", encoding='utf-8')
df = df.dropna(how='all')  # حذف الصفوف الفارغة بالكامل

def test_no_missing_values():
    """Check for missing values in main columns and warn instead of fail."""
    required_columns = ['الاسم', 'نوع الحدث', 'فتح', 'التاريخ', 'القائد', 'عهد', 'الموقع']

       missing_data = df[required_columns].isnull().sum()
    missing_columns = missing_data[missing_data > 0]

    if not missing_columns.empty:
        warnings.warn(f"Missing values found in columns: {missing_columns.to_dict()}")
    assert True  

def test_valid_event_types():
    """Ensure 'نوع الحدث' has only allowed values (handling merged text like 'معركةلفتح')."""
    valid_event_types = ['غزوة', 'معركة', 'فتح']

       cleaned_types = (
        df['نوع الحدث']
        .dropna()
        .astype(str)
        .str.strip()
        .str.replace(r'\s+', '', regex=True)
    )

        normalized_types = cleaned_types.apply(
        lambda x: next((word for word in valid_event_types if word in x), x)
    )

        invalid_values = normalized_types[~normalized_types.isin(valid_event_types)]

        assert invalid_values.empty, f"Invalid event types detected: {invalid_values.unique()}"

def test_numeric_columns_positive():
    """Ensure numeric columns have only positive values (ignoring NaNs)."""
    numeric_columns = ['عدد المسلمين', 'عدد الأعداء']

    for col in numeric_columns:
        non_null_values = pd.to_numeric(df[col], errors='coerce').dropna()
        assert (non_null_values > 0).all(), f"Column {col} contains non-positive values!"

